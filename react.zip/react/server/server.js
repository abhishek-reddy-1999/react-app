const express = require("express");
const cross = require("cors");
const sql = require("mssql");
const bodyParser = require("body-parser");
const app = express();
const path=require('path')
const PORT = 80;

app.use(cross());
app.use(bodyParser.json({ extended: true }));
app.use(bodyParser.urlencoded({ extended: true }));
// app.use(express.static(path.join(__dirname+"/build")))

var config = {
  user: "sa",
  password: "indotpt@2016",
  server: "IMTPT-IT-D03",
  database: "WAXTran",

  options: {
    trustedconnection: true,
    enableArithAbrot: true,
    trustServerCertificate: true,
    instancename: "",
    
  },
  port: 1433,
};

// app.get('/', function (req, res) {
//   res.sendFile(path.join(__dirname, 'build', 'index.html'));
// });

app.get('/bar', (req, res) => {
  var config = {
    user: "sa",
    password: "indotpt@2016",
    server: "IMTPT-IT-D03",
    database: "WAXTran",
    options: {
      trustedconnection: true,
      enableArithAbrot: true,
      trustServerCertificate: true,
      instancename: "",
    },
    port: 1433,
  };
  
  sql.connect(config, (err) => {
   
    
    if (err) {
      console.log("error in connection", err);
    } else {
      var request = new sql.Request();
      request.query(
        "select Sum(NoOfParts) as NoOfParts ,PartNo as name from Invoice where InvoiceDate between '2019-01-02' and '2019-01-07' group by PartNo ",
        (err, data) => {
          if (err) {
            console.log("Error in query", err);
          } else {
            res.send(data.recordset);
            // console.log(data.recordset)
          }
        }
      );
    }
  });
});

// app.get('/map',(req,res)=>{
//     var temp = {
//         user: "sa",
//         password: "indotpt@2016",
//         server: "IMTPT-IT-D03",
//         database: "invoicetmp",
//         options: {
//           trustedconnection: true,
//           enableArithAbrot: true,
//           trustServerCertificate: true,
//           instancename: "",
//         },
//         port: 1433,
//       };
//     sql.connect(temp,(err)=>{
//         if (err){
//             console.log("error in connection",err);
//         }
//         else{
//              var request= new sql.Request();
//                 request.query('select * from map',function(err,data){
//                     if(err){
//                         console.log ("Error in query", err)
//                     }
//                     else{
//                         res.send(data.recordset);
                       
//                     }
//                 })
//         }
//     }
// )
// }
// )

app.post('/date', (req, res) => {
  var config = {
    user: "sa",
    password: "indotpt@2016",
    server: "IMTPT-IT-D03",
    database: "WAXTran",
    options: {
      trustedconnection: true,
      enableArithAbrot: true,
      trustServerCertificate: true,
      instancename: "",
    },
    port: 1433,
  };
  
  var dates = {
    fromdate: req.body["fromdate"],
    todate: req.body["todate"],
  };
  var fromdate = dates.fromdate;
  var todate = dates.todate;

 
  sql.connect(config, (err) => {
    if (err) {
      console.log("error connecting to db");
    } 
    else {
      let request = new sql.Request();
      request.query(
        "select Sum(NoOfParts) as NoOfParts ,PartNo as name from Invoice where InvoiceDate between '"+fromdate+"' and '"+todate+"' group by PartNo ",
        function (err, data) {
          if (err) {
            console.log("error data retrive", err);
          } 
          else {
            res.send(data.recordset);
            // console.log(data.recordset);
          }
        }
      );
    }
  });
});

app.listen(PORT,"192.168.24.116",()=>{
  console.log(`server is running at http://192.168.24.116:${PORT}`)
})

