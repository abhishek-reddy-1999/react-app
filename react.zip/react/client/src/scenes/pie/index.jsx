import { Box } from "@mui/material";
import Header from "../../components/Header";
import PieCharts from "../../components/PieChart";

const Pie = () => {
  return (
    <Box m="20px">
      <Header title="Pie Chart" subtitle="Simple Pie Chart" />
      <Box height="85vh">
        <PieCharts />
      </Box>
    </Box>
  );
};

export default Pie;
