import axios from "axios";

const server_run = " http://192.168.0.114:4000";

export const getmap = async (user) => {
  return await axios.get(`${server_run}/map`, user);
};
export const getbar = async () => {
  return await axios.get(`${server_run}/bar`);
};
export const datewise = async (dates) => {
  return await axios.post(`${server_run}/date`,dates);
};
