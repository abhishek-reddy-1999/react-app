import { useTheme } from "@mui/material";

import { tokens } from "../theme";
import { mockBarData as data } from "../data/mockData";
import {
  BarChart,
  Bar,
  Brush,
  ReferenceLine,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

import { useEffect, useState,createContext,useContext } from "react";
import { getbar } from "../services/api";
import { userContext } from "../scenes/context/UserContext"; 


const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="label">{`${label} : ${payload[0].value}`}</p>
        
      </div>
    );
  }
}



const Bars = (props) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);


 
  // const [datas,setdata]=useState(props.data);

 const data=props.data

//  useEffect(()=>{
//       fetchUserData()

//  },[])

// const from=props.data.fromdate;
// const to=props.data.todate;
 
// const Dates={
//   fromdate:from,
//   todate:to,
//  }

// const fetchUserData= async (Dates)=>{
//   const response=await getbar(Dates);
//   setdata(response.data)
  
// }
// console.log(datas)

  return (
    <ResponsiveContainer width="100%" height="100%">
      
      <BarChart
      width={500}
      height={350}
      data={data}
      margin={{
        top: 5,
        right: 30,
        left: 20,
        bottom: 5
      }}
    >
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey="name" />
      <YAxis />
      <Tooltip content={<CustomTooltip />} />
      <Legend verticalAlign="top" wrapperStyle={{ lineHeight: "40px" }} />
      {/* <ReferenceLine y={0} stroke="#000" /> */}
      <Brush dataKey="name" height={30} stroke="#8884d8" />
      <Bar dataKey="amt" fill="#8884d8" />
     
    </BarChart>
      </ResponsiveContainer>
  );
};

export default Bars;
