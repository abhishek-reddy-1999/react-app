
import { useTheme } from "@mui/material";
import { tokens } from "../theme";
import { mockLineData as data } from "../data/mockData";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Res,
  ResponsiveContainer,
  Brush
} from "recharts";

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="label">{`${label} : ${payload[0].value}`}</p>
        
      </div>
    );
  }
}




const LineCharts = (props) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <ResponsiveContainer width="100%" >
    <LineChart
      width={300}
        height={300}
        data={props.data}
        syncId="anyId"
        margin={{
          top: 0,
          right: 30,
          left: 0,
          bottom: 20
        }}
        label
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip content={<CustomTooltip />} />
        <Line type="monotone" dataKey="amt" stroke="#82ca9d" fill="#82ca9d" />
        <Brush />
      </LineChart>
      </ResponsiveContainer>

  );
};

export default LineCharts;
